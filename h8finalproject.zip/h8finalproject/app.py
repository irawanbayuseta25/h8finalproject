from flask import Flask, request
from flask_restful import Resource, Api, reqparse
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///milestones.db'
db = SQLAlchemy(app)
api = Api(app)

# Model untuk database
class Milestone(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text)
    completed = db.Column(db.Boolean, default=False)

# Migrate database
db.create_all()

# Parser untuk input data pada request
parser = reqparse.RequestParser()
parser.add_argument('title', type=str, help='Title of the milestone')
parser.add_argument('description', type=str, help='Description of the milestone')
parser.add_argument('completed', type=bool, help='Completion status of the milestone')

# Resource untuk operasi CRUD
class MilestoneResource(Resource):
    def get(self, milestone_id):
        milestone = Milestone.query.get(milestone_id)
        if milestone:
            return {'id': milestone.id, 'title': milestone.title, 'description': milestone.description, 'completed': milestone.completed}
        else:
            return {'message': 'Milestone not found'}, 404

    def put(self, milestone_id):
        args = parser.parse_args()
        milestone = Milestone.query.get(milestone_id)
        if milestone:
            milestone.title = args['title']
            milestone.description = args['description']
            milestone.completed = args['completed']
            db.session.commit()
            return {'message': 'Milestone updated successfully'}
        else:
            return {'message': 'Milestone not found'}, 404

    def delete(self, milestone_id):
        milestone = Milestone.query.get(milestone_id)
        if milestone:
            db.session.delete(milestone)
            db.session.commit()
            return {'message': 'Milestone deleted successfully'}
        else:
            return {'message': 'Milestone not found'}, 404

# Resource untuk menampilkan semua milestones dan membuat milestone baru
class MilestoneListResource(Resource):
    def get(self):
        milestones = Milestone.query.all()
        result = []
        for milestone in milestones:
            result.append({'id': milestone.id, 'title': milestone.title, 'description': milestone.description, 'completed': milestone.completed})
        return result

    def post(self):
        args = parser.parse_args()
        milestone = Milestone(title=args['title'], description=args['description'], completed=args['completed'])
        db.session.add(milestone)
        db.session.commit()
        return {'message': 'Milestone created successfully'}, 201

# Setup resource routing
api.add_resource(MilestoneResource, '/milestones/<int:milestone_id>')
api.add_resource(MilestoneListResource, '/milestones')

if __name__ == '__main__':
    app.run(debug=True)

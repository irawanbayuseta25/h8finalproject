from flask import Flask
app = Flask(__name__)
@app.route('/')
def haloduniatiputipu():
    return'halo dunia tipu tipu!'